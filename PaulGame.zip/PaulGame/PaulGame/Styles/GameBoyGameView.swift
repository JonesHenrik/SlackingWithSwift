//
//  GameBoyGameView.swift
//  PaulGame
//
//  STYLE 3 — POCKET LCD
//
//  A 1989 handheld. Four shades of green, hard pixel edges, everything snapped
//  to a grid. Animation is quantised into discrete frames rather than
//  interpolated, which is what sells the LCD illusion.
//
//  Design note worth keeping regardless of which style wins: with only four
//  near-identical greens available, danger *cannot* be signalled by colour. It
//  is carried by a dither pattern, the border weight, and the text. That makes
//  this the most colourblind-safe of the four directions by construction.
//

import SwiftUI

struct GameBoyGameView: View {
    @Bindable var engine: GameEngine
    var onExit: () -> Void

    // The canonical DMG-01 palette.
    private let lightest = Color(hex: 0x9BBC0F)
    private let light = Color(hex: 0x8BAC0F)
    private let dark = Color(hex: 0x306230)
    private let darkest = Color(hex: 0x0F380F)

    var body: some View {
        TimelineView(.animation) { timeline in
            let now = timeline.date
            let threat = quantise(engine.threat(at: now), steps: 4)

            ZStack {
                darkest.ignoresSafeArea()

                VStack(spacing: 0) {
                    screen(now: now, threat: threat)
                        .background(lightest)
                        .overlay(Rectangle().stroke(darkest, lineWidth: 8))
                        .padding(10)

                    bezel
                }
            }
        }
        .holdSurface(engine)
        .ignoresSafeArea()
    }

    /// LCDs don't tween. Snapping continuous values to steps is what makes this
    /// read as hardware rather than as a modern app wearing a costume.
    private func quantise(_ value: Double, steps: Int) -> Double {
        (value * Double(steps)).rounded(.down) / Double(steps)
    }

    // MARK: - Screen

    private func screen(now: Date, threat: Double) -> some View {
        VStack(spacing: 0) {
            statusBar(now: now)

            Rectangle().fill(dark).frame(height: 3)

            ZStack {
                if threat > 0.4 { ditherOverlay(intensity: threat) }

                PixelSpriteView(
                    grid: PaulSprite.grid(for: engine.pose(at: now)),
                    palette: [
                        "h": darkest,
                        "s": light,
                        "t": dark,
                        "e": darkest,
                        "w": lightest,
                    ]
                )
                .frame(height: 260)
                .padding(.vertical, 12)

                if engine.phase == .caught { caughtPanel }
            }
            .frame(maxHeight: .infinity)

            Rectangle().fill(dark).frame(height: 3)

            bottomBar(now: now, threat: threat)
        }
    }

    private func statusBar(now: Date) -> some View {
        HStack(spacing: 0) {
            lcdText("SCORE", size: 10)
            Spacer()
            lcdText(engine.displayScore(at: now).scoreText, size: 20, weight: .black)
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 10)
    }

    private func bottomBar(now: Date, threat: Double) -> some View {
        VStack(spacing: 8) {
            HStack {
                lcdText(statusText, size: 13, weight: .black)
                Spacer()
                lcdText(String(format: "X%.1f", engine.currentMultiplier(at: now)), size: 13, weight: .bold)
            }

            // Chunky segmented meter — 10 discrete blocks, no smooth fill.
            HStack(spacing: 3) {
                ForEach(0..<10, id: \.self) { index in
                    let filled = engine.phase == .turning
                        ? Double(index) < (1 - threat) * 10
                        : true
                    Rectangle()
                        .fill(filled ? darkest : lightest)
                        .overlay(Rectangle().stroke(dark, lineWidth: 1))
                        .frame(height: 12)
                }
            }

            HStack {
                lcdText("HI \(engine.bestScore.scoreText)", size: 10)
                Spacer()
                Button(action: onExit) {
                    lcdText("< STYLES", size: 10, weight: .bold)
                        .frame(minWidth: 44, minHeight: 44, alignment: .trailing)
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 10)
    }

    private var statusText: String {
        switch engine.phase {
        case .idle:    return "HOLD A TO WORK"
        case .green:   return "CLEAR"
        case .fakeOut: return "..."
        case .turning: return "HE IS TURNING!"
        case .red:     return "SEEN!"
        case .caught:  return "GAME OVER"
        }
    }

    /// Danger as texture, not hue — a checkerboard that thickens as Paul turns.
    private func ditherOverlay(intensity: Double) -> some View {
        Canvas { context, size in
            let cell: CGFloat = 4
            let density = Int((1 - intensity) * 3) + 1
            var row = 0
            var y: CGFloat = 0
            while y < size.height {
                var column = 0
                var x: CGFloat = 0
                while x < size.width {
                    if (row + column) % density == 0 {
                        context.fill(
                            Path(CGRect(x: x, y: y, width: cell, height: cell)),
                            with: .color(dark.opacity(0.55))
                        )
                    }
                    x += cell
                    column += 1
                }
                y += cell
                row += 1
            }
        }
        .allowsHitTesting(false)
    }

    private var caughtPanel: some View {
        VStack(spacing: 14) {
            lcdText("GAME OVER", size: 26, weight: .black)
            Rectangle().fill(darkest).frame(height: 3).padding(.horizontal, 20)
            lcdText(engine.bankedScore.scoreText, size: 32, weight: .black)
            lcdText("\(engine.cycle) TURNS", size: 11)

            Button { engine.start() } label: {
                lcdText("> RETRY", size: 14, weight: .black)
                    .padding(.horizontal, 20)
                    .padding(.vertical, 12)
                    .overlay(Rectangle().stroke(darkest, lineWidth: 3))
                    .frame(minHeight: 44)
            }
            .buttonStyle(.plain)
            .padding(.top, 6)
        }
        .padding(26)
        .background(lightest)
        .overlay(Rectangle().stroke(darkest, lineWidth: 4))
        .padding(20)
    }

    private func lcdText(_ text: String, size: CGFloat, weight: Font.Weight = .bold) -> some View {
        Text(text)
            .font(.system(size: size, weight: weight, design: .monospaced))
            .tracking(size * 0.14)
            .foregroundStyle(darkest)
    }

    // MARK: - Hardware chrome

    private var bezel: some View {
        HStack {
            lcdText("PAUL BOY", size: 11, weight: .black)
                .foregroundStyle(lightest)
                .opacity(0.7)
            Spacer()
            HStack(spacing: 5) {
                ForEach(0..<3, id: \.self) { _ in
                    Circle().fill(dark).frame(width: 5, height: 5)
                }
            }
        }
        .padding(.horizontal, 24)
        .padding(.bottom, 14)
        .padding(.top, 4)
    }
}
