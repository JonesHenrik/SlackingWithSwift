//
//  ArcadeCRTGameView.swift
//  PaulGame
//
//  STYLE 1 — NEON ARCADE
//
//  An arcade cabinet at 2am. Near-black background, phosphor glow, scanlines,
//  chromatic aberration when you get busted. Hot magenta / cyan / lime.
//  Chunky monospaced type with heavy tracking.
//

import SwiftUI

struct ArcadeCRTGameView: View {
    @Bindable var engine: GameEngine
    var onExit: () -> Void

    private let void = Color(hex: 0x08060F)
    private let magenta = Color(hex: 0xFF2D95)
    private let cyan = Color(hex: 0x00F0FF)
    private let lime = Color(hex: 0xB6FF00)
    private let amber = Color(hex: 0xFFB300)

    var body: some View {
        TimelineView(.animation) { timeline in
            let now = timeline.date
            let threat = engine.threat(at: now)
            let accent = accentColor(threat: threat)

            ZStack {
                background(threat: threat)

                VStack(spacing: 0) {
                    header(now: now, accent: accent)
                    Spacer(minLength: 0)
                    paul(now: now, threat: threat, accent: accent)
                    Spacer(minLength: 0)
                    footer(now: now, threat: threat, accent: accent)
                }
                .padding(.horizontal, 24)
                .padding(.vertical, 20)

                scanlines
                vignette

                if engine.phase == .caught {
                    gameOver(accent: magenta)
                }
            }
            .modifier(ShakeEffect(amount: engine.phase == .caught ? 6 : threat * 3))
        }
        .background(void)
        .holdSurface(engine)
        .ignoresSafeArea()
        .statusBarHidden()
        .persistentSystemOverlays(.hidden)
    }

    // MARK: - Pieces

    private func accentColor(threat: Double) -> Color {
        switch engine.phase {
        case .caught, .red: return magenta
        case .turning:      return threat > 0.5 ? amber : cyan
        default:            return lime
        }
    }

    private func background(threat: Double) -> some View {
        ZStack {
            void
            RadialGradient(
                colors: [accentColor(threat: threat).opacity(0.28 * (0.3 + threat)), .clear],
                center: .center,
                startRadius: 20,
                endRadius: 420
            )
        }
    }

    private func header(now: Date, accent: Color) -> some View {
        HStack(alignment: .top) {
            VStack(alignment: .leading, spacing: 6) {
                Text("SCORE")
                    .font(.system(size: 11, weight: .bold, design: .monospaced))
                    .tracking(4)
                    .foregroundStyle(cyan.opacity(0.7))
                Text(engine.displayScore(at: now).scoreText)
                    .font(.system(size: 44, weight: .black, design: .monospaced))
                    .foregroundStyle(.white)
                    .glow(cyan, radius: 12)
                    .contentTransition(.numericText())
            }

            Spacer()

            VStack(alignment: .trailing, spacing: 6) {
                Text("HI-SCORE")
                    .font(.system(size: 11, weight: .bold, design: .monospaced))
                    .tracking(4)
                    .foregroundStyle(magenta.opacity(0.7))
                Text(engine.bestScore.scoreText)
                    .font(.system(size: 20, weight: .heavy, design: .monospaced))
                    .foregroundStyle(magenta)
                    .glow(magenta, radius: 8)

                Button(action: onExit) {
                    Text("[ EXIT ]")
                        .font(.system(size: 11, weight: .bold, design: .monospaced))
                        .tracking(2)
                        .foregroundStyle(.white.opacity(0.55))
                }
                .buttonStyle(.plain)
                .padding(.top, 8)
            }
        }
    }

    private func paul(now: Date, threat: Double, accent: Color) -> some View {
        let palette: [Character: Color] = [
            "h": Color(hex: 0x2B1B4D),
            "s": Color(hex: 0xFFD9C0),
            "t": accent,
            "e": Color(hex: 0x0A0A12),
            "w": .white,
        ]

        return ZStack {
            // Phosphor bloom.
            PixelSpriteView(grid: PaulSprite.grid(for: engine.pose(at: now)), palette: palette)
                .blur(radius: 18)
                .opacity(0.55 + threat * 0.4)
                .blendMode(.plusLighter)

            // Chromatic aberration — two offset copies, additive.
            let split = 1.5 + threat * 4
            PixelSpriteView(grid: PaulSprite.grid(for: engine.pose(at: now)),
                            palette: palette.mapValues { _ in Color(hex: 0xFF0044) })
                .offset(x: -split)
                .blendMode(.plusLighter)
                .opacity(0.5)
            PixelSpriteView(grid: PaulSprite.grid(for: engine.pose(at: now)),
                            palette: palette.mapValues { _ in Color(hex: 0x00FFEE) })
                .offset(x: split)
                .blendMode(.plusLighter)
                .opacity(0.5)

            PixelSpriteView(grid: PaulSprite.grid(for: engine.pose(at: now)), palette: palette)
        }
        .frame(height: 300)
    }

    private func footer(now: Date, threat: Double, accent: Color) -> some View {
        VStack(spacing: 18) {
            // Non-colour state signal: the label text itself carries the meaning.
            Text(statusText)
                .font(.system(size: 22, weight: .black, design: .monospaced))
                .tracking(6)
                .foregroundStyle(accent)
                .glow(accent, radius: 14)
                .padding(.horizontal, 22)
                .padding(.vertical, 12)
                .overlay(Rectangle().stroke(accent, lineWidth: 2))
                .glow(accent, radius: 8)

            // Reaction window drain bar.
            GeometryReader { proxy in
                ZStack(alignment: .leading) {
                    Rectangle().fill(.white.opacity(0.08))
                    Rectangle()
                        .fill(accent)
                        .frame(width: proxy.size.width * (engine.phase == .turning ? 1 - threat : 1))
                        .glow(accent, radius: 10)
                }
            }
            .frame(height: 6)

            HStack {
                Text("MULT")
                    .font(.system(size: 11, weight: .bold, design: .monospaced))
                    .tracking(3)
                    .foregroundStyle(.white.opacity(0.45))
                Text(String(format: "x%.1f", engine.currentMultiplier(at: now)))
                    .font(.system(size: 18, weight: .black, design: .monospaced))
                    .foregroundStyle(lime)
                    .glow(lime, radius: 8)
                Spacer()
                Text(engine.isHolding ? "▓ WORKING" : "░ IDLE")
                    .font(.system(size: 13, weight: .bold, design: .monospaced))
                    .tracking(2)
                    .foregroundStyle(engine.isHolding ? lime : .white.opacity(0.35))
            }
        }
    }

    private var statusText: String {
        switch engine.phase {
        case .idle:    return "HOLD TO WORK"
        case .green:   return "ALL CLEAR"
        case .fakeOut: return "...HUH?"
        case .turning: return "!! HE MOVED !!"
        case .red:     return "EYES ON YOU"
        case .caught:  return "BUSTED"
        }
    }

    private func gameOver(accent: Color) -> some View {
        ZStack {
            void.opacity(0.86)
            VStack(spacing: 22) {
                Text("BUSTED")
                    .font(.system(size: 62, weight: .black, design: .monospaced))
                    .tracking(8)
                    .foregroundStyle(accent)
                    .glow(accent, radius: 24)

                Text(engine.bankedScore.scoreText)
                    .font(.system(size: 54, weight: .black, design: .monospaced))
                    .foregroundStyle(.white)
                    .glow(cyan, radius: 16)

                Text("SURVIVED \(engine.cycle) TURNS")
                    .font(.system(size: 13, weight: .bold, design: .monospaced))
                    .tracking(3)
                    .foregroundStyle(cyan.opacity(0.8))

                HStack(spacing: 14) {
                    arcadeButton("RETRY", color: lime) { engine.start() }
                    arcadeButton("STYLES", color: cyan, action: onExit)
                }
                .padding(.top, 10)
            }
        }
        .transition(.opacity)
    }

    private func arcadeButton(_ title: String, color: Color, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 15, weight: .black, design: .monospaced))
                .tracking(3)
                .foregroundStyle(color)
                .padding(.horizontal, 26)
                .padding(.vertical, 14)
                .overlay(Rectangle().stroke(color, lineWidth: 2))
                .glow(color, radius: 10)
        }
        .buttonStyle(.plain)
    }

    private var scanlines: some View {
        Canvas { context, size in
            let spacing: CGFloat = 3
            var y: CGFloat = 0
            while y < size.height {
                context.fill(
                    Path(CGRect(x: 0, y: y, width: size.width, height: 1)),
                    with: .color(.black.opacity(0.32))
                )
                y += spacing
            }
        }
        .allowsHitTesting(false)
        .blendMode(.multiply)
    }

    private var vignette: some View {
        RadialGradient(
            colors: [.clear, .black.opacity(0.75)],
            center: .center,
            startRadius: 180,
            endRadius: 560
        )
        .allowsHitTesting(false)
    }
}

// MARK: - Helpers

private extension View {
    /// Stacked shadows read as phosphor bloom on a dark background.
    func glow(_ color: Color, radius: CGFloat) -> some View {
        self
            .shadow(color: color.opacity(0.9), radius: radius / 2)
            .shadow(color: color.opacity(0.5), radius: radius)
    }
}

/// Horizontal jitter, scaled by how much trouble you're in.
private struct ShakeEffect: ViewModifier {
    var amount: Double

    func body(content: Content) -> some View {
        content.offset(
            x: amount == 0 ? 0 : CGFloat.random(in: -amount...amount),
            y: amount == 0 ? 0 : CGFloat.random(in: -amount / 2...amount / 2)
        )
    }
}

#Preview {
    ArcadeCRTGameView(engine: GameEngine(), onExit: ())
}
