//
//  GameStyle.swift
//  PaulGame
//
//  The four design directions under evaluation.
//
//  Each style is a completely independent View over the shared GameEngine —
//  deliberately *not* a themed token system, which would flatten them toward
//  each other. Shared data, independent rendering.
//

import SwiftUI

enum GameStyle: String, CaseIterable, Identifiable {
    case arcadeCRT
    case liquidGlass
    case gameBoy
    case brutalist

    var id: String { rawValue }

    var title: String {
        switch self {
        case .arcadeCRT:   return "Neon Arcade"
        case .liquidGlass: return "Liquid Glass"
        case .gameBoy:     return "Pocket LCD"
        case .brutalist:   return "Loud Poster"
        }
    }

    var tagline: String {
        switch self {
        case .arcadeCRT:   return "CRT scanlines, phosphor glow, hot magenta on black"
        case .liquidGlass: return "Frosted panels over a mesh gradient that reacts to danger"
        case .gameBoy:     return "Four shades of green. Dithered patterns, no colour cues"
        case .brutalist:   return "Flat blocks, hard shadows, type that fills the screen"
        }
    }

    /// Swatches for the gallery cards.
    var swatch: [Color] {
        switch self {
        case .arcadeCRT:
            return [Color(hex: 0x08060F), Color(hex: 0xFF2D95), Color(hex: 0x00F0FF), Color(hex: 0xB6FF00)]
        case .liquidGlass:
            return [Color(hex: 0xEAF2FF), Color(hex: 0x8AD8C6), Color(hex: 0xB9A7F5), Color(hex: 0xFF7A6B)]
        case .gameBoy:
            return [Color(hex: 0x9BBC0F), Color(hex: 0x8BAC0F), Color(hex: 0x306230), Color(hex: 0x0F380F)]
        case .brutalist:
            return [Color(hex: 0xF4F1EA), Color(hex: 0xF05138), Color(hex: 0x2323FF), Color(hex: 0x101010)]
        }
    }

    @MainActor @ViewBuilder
    func makeView(engine: GameEngine, onExit: @escaping () -> Void) -> some View {
        switch self {
        case .arcadeCRT:   ArcadeCRTGameView(engine: engine, onExit: onExit)
        case .liquidGlass: LiquidGlassGameView(engine: engine, onExit: onExit)
        case .gameBoy:     GameBoyGameView(engine: engine, onExit: onExit)
        case .brutalist:   BrutalistGameView(engine: engine, onExit: onExit)
        }
    }
}

extension Color {
    init(hex: UInt32) {
        self.init(
            .sRGB,
            red: Double((hex >> 16) & 0xFF) / 255,
            green: Double((hex >> 8) & 0xFF) / 255,
            blue: Double(hex & 0xFF) / 255,
            opacity: 1
        )
    }
}

/// Shared hold gesture. `onChanged` fires repeatedly, so `beginHold` is
/// idempotent by design. DragGesture with a zero minimum distance is used
/// instead of LongPressGesture, which has a built-in delay that would corrupt
/// the timing (see plan.md).
extension View {
    func holdSurface(_ engine: GameEngine) -> some View {
        self.contentShape(Rectangle())
            .gesture(
                DragGesture(minimumDistance: 0)
                    .onChanged { _ in engine.beginHold() }
                    .onEnded { _ in engine.endHold() }
            )
    }
}
