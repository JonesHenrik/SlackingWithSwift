//
//  LiquidGlassGameView.swift
//  PaulGame
//
//  STYLE 2 — LIQUID GLASS
//
//  The modern Apple direction. A living MeshGradient behind frosted glass
//  panels, SF Rounded throughout, generous spacing, spring animation. The
//  background itself is the danger signal: calm mint and lavender bloom into
//  coral as Paul turns, so the whole screen breathes with the game state.
//

import SwiftUI

struct LiquidGlassGameView: View {
    @Bindable var engine: GameEngine
    var onExit: () -> Void

    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    private let calm = Color(hex: 0x8AD8C6)
    private let lilac = Color(hex: 0xB9A7F5)
    private let alarm = Color(hex: 0xFF7A6B)
    private let ink = Color(hex: 0x1B2340)

    var body: some View {
        TimelineView(.animation) { timeline in
            let now = timeline.date
            let threat = engine.threat(at: now)

            ZStack {
                mesh(threat: threat, time: now.timeIntervalSinceReferenceDate)

                VStack(spacing: 24) {
                    header(now: now)
                    Spacer(minLength: 0)
                    paul(now: now, threat: threat)
                    Spacer(minLength: 0)
                    statusCard(now: now, threat: threat)
                }
                .padding(.horizontal, 22)
                .padding(.vertical, 28)

                if engine.phase == .caught {
                    gameOver
                }
            }
        }
        .holdSurface(engine)
        .ignoresSafeArea()
    }

    // MARK: - Background

    /// Six-point mesh that warms toward coral as threat rises. The drift is
    /// suppressed under Reduce Motion.
    private func mesh(threat: Double, time: TimeInterval) -> some View {
        let drift = reduceMotion ? 0 : Float(sin(time * 0.6) * 0.06)
        let danger = Float(threat)

        return MeshGradient(
            width: 3,
            height: 3,
            points: [
                [0, 0], [0.5, 0], [1, 0],
                [0, 0.5], [0.5 + drift, 0.5 - drift], [1, 0.5],
                [0, 1], [0.5, 1], [1, 1],
            ],
            colors: [
                Color(hex: 0xEAF2FF), blend(lilac, alarm, danger), Color(hex: 0xF3ECFF),
                blend(calm, alarm, danger), .white, blend(lilac, alarm, danger * 0.8),
                Color(hex: 0xE4F7F1), blend(calm, alarm, danger), Color(hex: 0xFFF4EC),
            ]
        )
        .overlay(Color.white.opacity(0.18 - threat * 0.18))
        .animation(.easeInOut(duration: 0.25), value: danger)
    }

    private func blend(_ a: Color, _ b: Color, _ t: Float) -> Color {
        a.mix(with: b, by: Double(min(max(t, 0), 1)))
    }

    // MARK: - Pieces

    private func header(now: Date) -> some View {
        HStack(spacing: 14) {
            VStack(alignment: .leading, spacing: 2) {
                Text("Score")
                    .font(.system(.caption, design: .rounded).weight(.semibold))
                    .foregroundStyle(ink.opacity(0.5))
                Text(engine.displayScore(at: now).scoreText)
                    .font(.system(size: 40, weight: .bold, design: .rounded))
                    .foregroundStyle(ink)
                    .contentTransition(.numericText())
            }

            Spacer()

            VStack(alignment: .trailing, spacing: 2) {
                Label(engine.bestScore.scoreText, systemImage: "trophy.fill")
                    .font(.system(.subheadline, design: .rounded).weight(.semibold))
                    .foregroundStyle(ink.opacity(0.65))
                Text(String(format: "×%.1f", engine.currentMultiplier(at: now)))
                    .font(.system(.title3, design: .rounded).weight(.heavy))
                    .foregroundStyle(engine.isHolding ? Color(hex: 0x0E9F7E) : ink.opacity(0.35))
                    .contentTransition(.numericText())
            }

            Button(action: onExit) {
                Image(systemName: "xmark")
                    .font(.system(size: 15, weight: .bold))
                    .foregroundStyle(ink.opacity(0.6))
                    .frame(width: 44, height: 44)
            }
            .buttonStyle(.plain)
            .glassEffect(.regular.interactive(), in: .circle)
            .accessibilityLabel("Close and choose another style")
        }
        .padding(18)
        .glassEffect(.regular, in: .rect(cornerRadius: 28))
    }

    private func paul(now: Date, threat: Double) -> some View {
        let palette: [Character: Color] = [
            "h": Color(hex: 0x3B2E5A),
            "s": Color(hex: 0xFFD5BC),
            "t": blend(Color(hex: 0x5B8DEF), alarm, Float(threat)),
            "e": Color(hex: 0x241E38),
            "w": .white,
        ]

        return PixelSpriteView(
            grid: PaulSprite.grid(for: engine.pose(at: now)),
            palette: palette,
            pixelInset: 0.6,
            cornerRadius: 3
        )
        .frame(height: 300)
        .shadow(color: ink.opacity(0.18), radius: 24, y: 14)
        .scaleEffect(reduceMotion ? 1 : 1 + threat * 0.06)
        .animation(.spring(duration: 0.3), value: threat > 0.5)
    }

    private func statusCard(now: Date, threat: Double) -> some View {
        VStack(spacing: 18) {
            // Icon + text carry the state, not colour alone.
            HStack(spacing: 12) {
                Image(systemName: statusIcon)
                    .font(.system(size: 26, weight: .semibold))
                    .foregroundStyle(statusTint)
                    .symbolEffect(.pulse, isActive: engine.phase == .turning)

                VStack(alignment: .leading, spacing: 2) {
                    Text(statusTitle)
                        .font(.system(.title3, design: .rounded).weight(.bold))
                        .foregroundStyle(ink)
                    Text(statusDetail)
                        .font(.system(.footnote, design: .rounded))
                        .foregroundStyle(ink.opacity(0.55))
                }
                Spacer()
            }

            // Reaction window, draining.
            GeometryReader { proxy in
                ZStack(alignment: .leading) {
                    Capsule().fill(ink.opacity(0.10))
                    Capsule()
                        .fill(statusTint.gradient)
                        .frame(width: proxy.size.width * (engine.phase == .turning ? 1 - threat : 1))
                }
            }
            .frame(height: 10)
        }
        .padding(22)
        .glassEffect(.regular, in: .rect(cornerRadius: 32))
    }

    private var statusIcon: String {
        switch engine.phase {
        case .idle:    return "hand.tap.fill"
        case .green:   return "checkmark.shield.fill"
        case .fakeOut: return "questionmark.circle.fill"
        case .turning: return "exclamationmark.triangle.fill"
        case .red:     return "eye.fill"
        case .caught:  return "hand.raised.fill"
        }
    }

    private var statusTitle: String {
        switch engine.phase {
        case .idle:    return "Hold to work"
        case .green:   return "He's not looking"
        case .fakeOut: return "False alarm"
        case .turning: return "Let go!"
        case .red:     return "He's watching"
        case .caught:  return "Caught"
        }
    }

    private var statusDetail: String {
        switch engine.phase {
        case .idle:    return "Press and hold anywhere to start earning"
        case .green:   return "Multiplier climbing — hold as long as you dare"
        case .fakeOut: return "He just shifted in his chair"
        case .turning: return "Release before he comes all the way round"
        case .red:     return "Don't touch the screen"
        case .caught:  return "Run over"
        }
    }

    private var statusTint: Color {
        switch engine.phase {
        case .turning, .red, .caught: return alarm
        case .fakeOut:                return Color(hex: 0xE8A33D)
        default:                      return Color(hex: 0x0E9F7E)
        }
    }

    private var gameOver: some View {
        ZStack {
            Rectangle().fill(.ultraThinMaterial)

            VStack(spacing: 10) {
                Image(systemName: "hand.raised.fill")
                    .font(.system(size: 46, weight: .semibold))
                    .foregroundStyle(alarm)
                    .padding(.bottom, 6)

                Text("Paul saw you")
                    .font(.system(.largeTitle, design: .rounded).weight(.heavy))
                    .foregroundStyle(ink)

                Text(engine.bankedScore.scoreText)
                    .font(.system(size: 64, weight: .black, design: .rounded))
                    .foregroundStyle(ink)
                    .contentTransition(.numericText())

                Text("\(engine.cycle) turns survived")
                    .font(.system(.subheadline, design: .rounded))
                    .foregroundStyle(ink.opacity(0.55))

                HStack(spacing: 12) {
                    Button { engine.start() } label: {
                        Label("Again", systemImage: "arrow.clockwise")
                            .font(.system(.headline, design: .rounded))
                            .padding(.horizontal, 22).padding(.vertical, 14)
                    }
                    .buttonStyle(.plain)
                    .foregroundStyle(.white)
                    .background(ink, in: .capsule)

                    Button(action: onExit) {
                        Label("Styles", systemImage: "paintpalette")
                            .font(.system(.headline, design: .rounded))
                            .padding(.horizontal, 22).padding(.vertical, 14)
                    }
                    .buttonStyle(.plain)
                    .foregroundStyle(ink)
                    .glassEffect(.regular.interactive(), in: .capsule)
                }
                .padding(.top, 18)
            }
            .padding(34)
            .glassEffect(.regular, in: .rect(cornerRadius: 40))
            .padding(28)
        }
        .transition(.opacity.combined(with: .scale(scale: 1.04)))
    }
}
