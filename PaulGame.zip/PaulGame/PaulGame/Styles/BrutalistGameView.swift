//
//  BrutalistGameView.swift
//  PaulGame
//
//  STYLE 4 — LOUD POSTER
//
//  Swiss/Bauhaus brutalism. Flat colour blocks, zero gradients, hard offset
//  shadows with no blur, 4pt black rules, and type at a size that stops being
//  polite. The whole background slams to a new flat colour on state change
//  rather than easing — the abruptness is the point.
//
//  Paul is not drawn from the pixel grid here. At this scale pixel art fights
//  the poster language, so he's reduced to geometric primitives instead.
//

import SwiftUI

struct BrutalistGameView: View {
    @Bindable var engine: GameEngine
    var onExit: () -> Void

    private let paper = Color(hex: 0xF4F1EA)
    private let ink = Color(hex: 0x101010)
    private let orange = Color(hex: 0xF05138)
    private let blue = Color(hex: 0x2323FF)
    private let yellow = Color(hex: 0xFFD400)

    var body: some View {
        TimelineView(.animation) { timeline in
            let now = timeline.date
            let threat = engine.threat(at: now)

            ZStack {
                fieldColor.ignoresSafeArea()

                VStack(alignment: .leading, spacing: 0) {
                    scoreBlock(now: now)
                    Spacer(minLength: 0)
                    paulBlock(now: now, threat: threat)
                    Spacer(minLength: 0)
                    stateBlock(now: now, threat: threat)
                }
                .padding(16)

                if engine.phase == .caught { gameOver }
            }
        }
        .holdSurface(engine)
        .ignoresSafeArea()
    }

    /// Flat, instant colour changes — no interpolation.
    private var fieldColor: Color {
        switch engine.phase {
        case .idle, .green: return paper
        case .fakeOut:      return yellow
        case .turning:      return yellow
        case .red:          return orange
        case .caught:       return orange
        }
    }

    // MARK: - Blocks

    private func scoreBlock(now: Date) -> some View {
        VStack(alignment: .leading, spacing: -12) {
            HStack(alignment: .top) {
                Text("SCORE")
                    .font(.system(size: 14, weight: .black))
                    .tracking(6)
                    .foregroundStyle(ink)

                Spacer()

                Button(action: onExit) {
                    Text("✕")
                        .font(.system(size: 20, weight: .black))
                        .foregroundStyle(paper)
                        .frame(width: 44, height: 44)
                        .background(ink)
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Close and choose another style")
            }

            Text(engine.displayScore(at: now).scoreText)
                .font(.system(size: 78, weight: .black))
                .tracking(-4)
                .foregroundStyle(ink)
                .minimumScaleFactor(0.4)
                .lineLimit(1)
                .contentTransition(.numericText())

            HStack(spacing: 8) {
                tag(String(format: "×%.1f", engine.currentMultiplier(at: now)), background: blue, foreground: paper)
                tag("BEST \(engine.bestScore.scoreText)", background: ink, foreground: paper)
            }
            .padding(.top, 22)
        }
    }

    private func paulBlock(now: Date, threat: Double) -> some View {
        // Geometric Paul: circle head, rectangle body, a bar for the arm.
        let pose = engine.pose(at: now)
        let rotation: Double = {
            switch pose {
            case .away: return 0
            case .quarter: return 38
            case .facing, .caught: return 90
            }
        }()

        return ZStack {
            Circle()
                .fill(blue)
                .frame(width: 210, height: 210)
                .offset(x: 30, y: -10)

            VStack(spacing: 6) {
                ZStack {
                    Circle().fill(paper)
                        .overlay(Circle().stroke(ink, lineWidth: 5))
                        .frame(width: 96, height: 96)

                    // Facing direction expressed as position, never colour.
                    HStack(spacing: 12) {
                        Circle().fill(ink).frame(width: 12, height: 12)
                        Circle().fill(ink).frame(width: 12, height: 12)
                    }
                    .opacity(pose == .away ? 0 : 1)
                    .offset(x: pose == .quarter ? 16 : 0, y: -4)

                    // Back of head marker.
                    Circle().fill(ink)
                        .frame(width: 46, height: 46)
                        .opacity(pose == .away ? 1 : 0)
                }
                .rotationEffect(.degrees(rotation * 0.12))

                Rectangle()
                    .fill(pose == .away ? ink : orange)
                    .frame(width: 128, height: 130)
                    .overlay(Rectangle().stroke(ink, lineWidth: 5))
                    .overlay(alignment: .trailing) {
                        // Accusatory arm.
                        Rectangle()
                            .fill(ink)
                            .frame(width: pose == .caught ? 84 : 0, height: 18)
                            .offset(x: pose == .caught ? 84 : 0, y: -22)
                    }
            }
            .shadow(color: ink, radius: 0, x: 10, y: 10)
        }
        .frame(height: 300)
        .frame(maxWidth: .infinity)
    }

    private func stateBlock(now: Date, threat: Double) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(statusText)
                .font(.system(size: statusSize, weight: .black))
                .tracking(-2)
                .foregroundStyle(engine.phase == .red || engine.phase == .caught ? paper : ink)
                .minimumScaleFactor(0.3)
                .lineLimit(2)
                .fixedSize(horizontal: false, vertical: true)

            // Window meter as a hard-edged bar, not a capsule.
            GeometryReader { proxy in
                ZStack(alignment: .leading) {
                    Rectangle().fill(paper)
                    Rectangle()
                        .fill(engine.phase == .turning ? orange : blue)
                        .frame(width: proxy.size.width * (engine.phase == .turning ? 1 - threat : 1))
                }
                .overlay(Rectangle().stroke(ink, lineWidth: 4))
            }
            .frame(height: 26)

            Text(engine.isHolding ? "HOLDING — KEEP EARNING" : "NOT HOLDING — NO POINTS")
                .font(.system(size: 12, weight: .black))
                .tracking(3)
                .foregroundStyle(engine.phase == .red || engine.phase == .caught ? paper.opacity(0.85) : ink.opacity(0.6))
        }
        .padding(.top, 10)
    }

    private var statusSize: CGFloat {
        switch engine.phase {
        case .turning, .red: return 62
        default:             return 40
        }
    }

    private var statusText: String {
        switch engine.phase {
        case .idle:    return "HOLD\nTO WORK"
        case .green:   return "HE'S FACING\nTHE WALL"
        case .fakeOut: return "FALSE ALARM"
        case .turning: return "LET GO"
        case .red:     return "HE SEES YOU"
        case .caught:  return "CAUGHT"
        }
    }

    private func tag(_ text: String, background: Color, foreground: Color) -> some View {
        Text(text)
            .font(.system(size: 13, weight: .black))
            .tracking(2)
            .foregroundStyle(foreground)
            .padding(.horizontal, 12)
            .padding(.vertical, 8)
            .background(background)
    }

    private var gameOver: some View {
        VStack(alignment: .leading, spacing: 0) {
            Spacer()

            Text("CAUGHT")
                .font(.system(size: 86, weight: .black))
                .tracking(-5)
                .foregroundStyle(paper)
                .minimumScaleFactor(0.4)
                .lineLimit(1)

            Rectangle().fill(ink).frame(height: 8).padding(.vertical, 14)

            Text(engine.bankedScore.scoreText)
                .font(.system(size: 96, weight: .black))
                .tracking(-6)
                .foregroundStyle(ink)
                .minimumScaleFactor(0.3)
                .lineLimit(1)
                .contentTransition(.numericText())

            Text("\(engine.cycle) TURNS SURVIVED")
                .font(.system(size: 14, weight: .black))
                .tracking(4)
                .foregroundStyle(ink.opacity(0.7))
                .padding(.top, 6)

            Spacer()

            HStack(spacing: 10) {
                Button { engine.start() } label: {
                    Text("RETRY")
                        .font(.system(size: 18, weight: .black))
                        .tracking(3)
                        .foregroundStyle(paper)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 20)
                        .background(ink)
                        .shadow(color: blue, radius: 0, x: 7, y: 7)
                }
                .buttonStyle(.plain)

                Button(action: onExit) {
                    Text("STYLES")
                        .font(.system(size: 18, weight: .black))
                        .tracking(3)
                        .foregroundStyle(ink)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 20)
                        .background(paper)
                        .overlay(Rectangle().stroke(ink, lineWidth: 4))
                }
                .buttonStyle(.plain)
            }
            .padding(.bottom, 20)
        }
        .padding(24)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(orange)
        .ignoresSafeArea()
    }
}
