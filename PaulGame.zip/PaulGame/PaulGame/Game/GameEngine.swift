//
//  GameEngine.swift
//  PaulGame
//
//  The state machine. Shared by all four visual styles.
//
//  Two rules from plan.md are load-bearing here:
//
//  1. No tick loop. Phase transitions run off absolute deadlines via
//     `Task.sleep`, and score is derived from elapsed time with a closed-form
//     integral. Nothing accumulates per frame, so nothing drifts.
//
//  2. Catch detection is event-driven, never polled. There are exactly two ways
//     to get caught: still holding when the turn completes, or starting a hold
//     while Paul is already looking. Both are events, so a 0.35s window stays
//     exact.
//

import SwiftUI

enum GamePhase: Equatable {
    /// Pre-run, waiting for first touch.
    case idle
    /// Back turned. Hold freely.
    case green
    /// A twitch that never becomes a turn. Holding stays safe.
    case fakeOut
    /// Turning toward you. Release before this ends.
    case turning
    /// Looking right at you. Any new hold is a catch.
    case red
    /// Run over.
    case caught

    /// Whether a hold started now is safe.
    var acceptsNewHold: Bool {
        switch self {
        case .idle, .green, .fakeOut, .turning: return true
        case .red, .caught: return false
        }
    }
}

private let bestScoreKey = "PaulGame.bestScore"

@MainActor
@Observable
final class GameEngine {
    private(set) var phase: GamePhase = .idle
    private(set) var isHolding = false
    private(set) var cycle = 0
    /// Score already banked from completed holds.
    private(set) var bankedScore: Double = 0
    private(set) var bestScore: Double = UserDefaults.standard.double(forKey: bestScoreKey)
    /// Set briefly when the player releases inside the nerve window.
    private(set) var nerveFlashID: Int = 0
    private(set) var didEarnNerveBonus = false

    var curve = DifficultyCurve()

    private var phaseStart: Date = .now
    private var phaseDuration: TimeInterval = 1
    private var holdStart: Date?
    private var loop: Task<Void, Never>?

    // MARK: - Derived state

    /// 0...1 through the current phase. Views drive animation off this.
    func phaseProgress(at date: Date) -> Double {
        guard phaseDuration > 0 else { return 1 }
        return min(max(date.timeIntervalSince(phaseStart) / phaseDuration, 0), 1)
    }

    func heldSeconds(at date: Date) -> Double {
        guard let holdStart else { return 0 }
        return max(date.timeIntervalSince(holdStart), 0)
    }

    /// Banked score plus the in-progress hold, for live display.
    func displayScore(at date: Date) -> Double {
        bankedScore + curve.score(forHoldOf: heldSeconds(at: date))
    }

    func currentMultiplier(at date: Date) -> Double {
        isHolding ? curve.multiplier(forHoldOf: heldSeconds(at: date)) : 1
    }

    /// Which sprite to draw. The turn ramps through poses so the player can
    /// read how much time is left.
    func pose(at date: Date) -> PaulPose {
        switch phase {
        case .idle, .green:
            return .away
        case .fakeOut:
            let p = phaseProgress(at: date)
            return (p > 0.25 && p < 0.7) ? .quarter : .away
        case .turning:
            let p = phaseProgress(at: date)
            if p < 0.35 { return .away }
            if p < 0.80 { return .quarter }
            return .facing
        case .red:
            return .facing
        case .caught:
            return .caught
        }
    }

    /// How exposed the player is right now, 0 (safe) to 1 (seen). Styles use
    /// this to drive colour, glow, shake — anything that should intensify.
    func threat(at date: Date) -> Double {
        switch phase {
        case .idle, .green: return 0
        case .fakeOut:      return phaseProgress(at: date) < 0.7 ? 0.35 : 0
        case .turning:      return phaseProgress(at: date)
        case .red, .caught: return 1
        }
    }

    // MARK: - Input

    func beginHold() {
        guard !isHolding, phase != .caught else { return }

        guard phase.acceptsNewHold else {
            // Reaching for the phone while Paul is watching.
            endRun()
            return
        }

        if phase == .idle { start() }
        isHolding = true
        holdStart = .now
        didEarnNerveBonus = false
    }

    func endHold() {
        guard isHolding else { return }
        let now = Date.now
        bankedScore += curve.score(forHoldOf: heldSeconds(at: now))

        // Nerve bonus: released inside the final slice of the turn.
        if phase == .turning, phaseProgress(at: now) >= 1 - curve.nerveWindowFraction {
            bankedScore += curve.nerveBonus
            didEarnNerveBonus = true
            nerveFlashID += 1
        }

        isHolding = false
        holdStart = nil
    }

    // MARK: - Run lifecycle

    func start() {
        loop?.cancel()
        bankedScore = 0
        cycle = 0
        isHolding = false
        holdStart = nil
        didEarnNerveBonus = false
        loop = Task { await self.run() }
    }

    func reset() {
        loop?.cancel()
        loop = nil
        phase = .idle
        isHolding = false
        holdStart = nil
        bankedScore = 0
        cycle = 0
    }

    func stop() {
        loop?.cancel()
        loop = nil
    }

    private func run() async {
        while !Task.isCancelled {
            await enter(.green, for: curve.greenDuration(cycle: cycle))
            guard !Task.isCancelled else { return }

            if Double.random(in: 0...1) < curve.fakeOutChance(cycle: cycle) {
                await enter(.fakeOut, for: 0.45)
                guard !Task.isCancelled else { return }
                continue
            }

            await enter(.turning, for: curve.reactionWindow(cycle: cycle))
            guard !Task.isCancelled else { return }

            // Event 1: the turn finished and the player never let go.
            if isHolding {
                endRun()
                return
            }

            await enter(.red, for: curve.redDuration())
            guard !Task.isCancelled else { return }

            cycle += 1
        }
    }

    private func enter(_ newPhase: GamePhase, for duration: TimeInterval) async {
        phase = newPhase
        phaseStart = .now
        phaseDuration = duration
        try? await Task.sleep(for: .seconds(duration))
    }

    private func endRun() {
        loop?.cancel()
        loop = nil

        if isHolding {
            bankedScore += curve.score(forHoldOf: heldSeconds(at: .now))
            isHolding = false
            holdStart = nil
        }

        phase = .caught

        if bankedScore > bestScore {
            bestScore = bankedScore
            UserDefaults.standard.set(bestScore, forKey: bestScoreKey)
        }
    }
}

extension Double {
    /// Score formatting shared by every style.
    var scoreText: String {
        Int(rounded()).formatted(.number.grouping(.automatic))
    }
}
