//
//  PaulSprite.swift
//  PaulGame
//
//  Shared pixel data for the 8-bit Paul character.
//
//  This file holds only the *shape* of Paul — a 16x18 character grid per pose.
//  Every visual style maps those characters to its own palette and renders them
//  however it likes, so the four styles can look nothing alike while staying in
//  sync with the game state.
//
//  Legend:
//    "." transparent   "h" hair    "s" skin
//    "t" shirt         "e" dark detail (eyes, mouth)    "w" highlight
//

import SwiftUI

enum PaulPose {
    /// Back turned. Safe to hold.
    case away
    /// Mid-turn, three-quarter profile. The tell.
    case quarter
    /// Looking straight at you.
    case facing
    /// Caught you — pointing.
    case caught
}

enum PaulSprite {
    static let columns = 16
    static let rows = 18

    static func grid(for pose: PaulPose) -> [String] {
        switch pose {
        case .away:    return away
        case .quarter: return quarter
        case .facing:  return facing
        case .caught:  return caught
        }
    }

    private static let away = [
        "................",
        "....hhhhhhhh....",
        "...hhhhhhhhhh...",
        "..hhhhhhhhhhhh..",
        "..hhhhhhhhhhhh..",
        "..hhhhhhhhhhhh..",
        "...hhhhhhhhhh...",
        "....ssssssss....",
        "...ssssssssss...",
        ".....ssssss.....",
        "..tttttttttttt..",
        ".tttttttttttttt.",
        "stttttttttttttts",
        "stttttttttttttts",
        "stttttttttttttts",
        ".tttttttttttttt.",
        "....ttt..ttt....",
        "....hhh..hhh....",
    ]

    private static let quarter = [
        "................",
        "....hhhhhhhh....",
        "...hhhhhhhhhh...",
        "..hhhhhhhhhhss..",
        "..hhhhhhhhhsee..",
        "..hhhhhhhhhsss..",
        "...hhhhhhhhss...",
        "....sssssssss...",
        "...ssssssssss...",
        ".....ssssss.....",
        "..tttttttttttt..",
        ".tttttttttttttt.",
        "stttttttttttttts",
        "stttttttttttttts",
        "stttttttttttttts",
        ".tttttttttttttt.",
        "....ttt..ttt....",
        "....hhh..hhh....",
    ]

    private static let facing = [
        "................",
        "....hhhhhhhh....",
        "...hhhhhhhhhh...",
        "..hhhhhhhhhhhh..",
        "..hssssssssssh..",
        "..ssweesseewss..",
        "..ssssssssssss..",
        "...ssseeeesss...",
        "...ssssssssss...",
        ".....ssssss.....",
        "..tttttttttttt..",
        ".tttttttttttttt.",
        "stttttttttttttts",
        "stttttttttttttts",
        "stttttttttttttts",
        ".tttttttttttttt.",
        "....ttt..ttt....",
        "....hhh..hhh....",
    ]

    private static let caught = [
        "................",
        "....hhhhhhhh....",
        "...hhhhhhhhhh...",
        "..hhhhhhhhhhhh..",
        "..hssssssssssh..",
        "..sseeesseeess..",
        "..ssssssssssss..",
        "...sseeeeeess...",
        "...ssssssssss...",
        ".....ssssss.....",
        "..tttttttttttt..",
        ".tttttttttttttt.",
        "stttttttttttttts",
        "sttttttttttttsss",
        "stttttttttttttts",
        ".tttttttttttttt.",
        "....ttt..ttt....",
        "....hhh..hhh....",
    ]
}

/// Renders a `PaulSprite` grid through an arbitrary palette.
///
/// Parameterised enough that each style gets its own character: the CRT style
/// uses square pixels with glow, Liquid Glass uses rounded inset pixels, and
/// the Game Boy style uses hard-edged pixels with zero spacing.
struct PixelSpriteView: View {
    let grid: [String]
    let palette: [Character: Color]
    var pixelInset: CGFloat = 0
    var cornerRadius: CGFloat = 0

    var body: some View {
        Canvas { context, size in
            let cell = min(size.width / CGFloat(PaulSprite.columns),
                           size.height / CGFloat(PaulSprite.rows))
            let originX = (size.width - cell * CGFloat(PaulSprite.columns)) / 2
            let originY = (size.height - cell * CGFloat(PaulSprite.rows)) / 2

            for (row, line) in grid.enumerated() {
                for (column, character) in line.enumerated() {
                    guard let color = palette[character] else { continue }
                    let rect = CGRect(
                        x: originX + CGFloat(column) * cell + pixelInset,
                        y: originY + CGFloat(row) * cell + pixelInset,
                        width: cell - pixelInset * 2,
                        height: cell - pixelInset * 2
                    )
                    let shape = cornerRadius > 0
                        ? Path(roundedRect: rect, cornerRadius: cornerRadius)
                        : Path(rect)
                    context.fill(shape, with: .color(color))
                }
            }
        }
        .accessibilityHidden(true)
    }
}
