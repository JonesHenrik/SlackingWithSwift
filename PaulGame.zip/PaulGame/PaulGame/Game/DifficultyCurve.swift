//
//  DifficultyCurve.swift
//  PaulGame
//
//  Every tuning constant in the game lives here, so playtesting is a
//  single-file edit. See plan.md.
//

import Foundation

struct DifficultyCurve {
    /// Cycles it takes to reach maximum difficulty.
    var rampCycles: Double = 20

    // Reaction window: how long Paul's turn takes. This is your time to release.
    var reactionWindowStart: Double = 0.90
    var reactionWindowFloor: Double = 0.35

    // How long Paul faces away (safe to hold).
    var greenMinStart: Double = 2.5
    var greenMinFloor: Double = 1.2
    var greenMaxStart: Double = 5.0
    var greenMaxFloor: Double = 2.5

    // How long Paul stares at you before turning back.
    var redRange: ClosedRange<Double> = 0.8...1.6

    // Chance Paul twitches without committing to a turn.
    var fakeOutChanceFloor: Double = 0.0
    var fakeOutChanceCeiling: Double = 0.30

    // Scoring.
    var pointsPerSecond: Double = 100
    var multiplierGainPerSecond: Double = 0.5
    var multiplierCap: Double = 5
    var nerveBonus: Double = 500
    /// Releasing inside the final slice of the window earns the nerve bonus.
    var nerveWindowFraction: Double = 0.25

    /// 0 at the start of a run, 1 once difficulty is maxed.
    func ramp(_ cycle: Int) -> Double {
        min(Double(cycle) / rampCycles, 1)
    }

    func reactionWindow(cycle: Int) -> Double {
        lerp(reactionWindowStart, reactionWindowFloor, ramp(cycle))
    }

    func greenDuration(cycle: Int) -> Double {
        let t = ramp(cycle)
        let low = lerp(greenMinStart, greenMinFloor, t)
        let high = lerp(greenMaxStart, greenMaxFloor, t)
        return Double.random(in: low...high)
    }

    func redDuration() -> Double {
        Double.random(in: redRange)
    }

    func fakeOutChance(cycle: Int) -> Double {
        lerp(fakeOutChanceFloor, fakeOutChanceCeiling, ramp(cycle))
    }

    /// Closed-form score for a continuous hold of `seconds`.
    ///
    /// The multiplier climbs linearly to its cap, so total points are the
    /// integral of `pointsPerSecond * multiplier(t)`. Solving it directly means
    /// score never depends on a timer firing — it is pure elapsed-time math.
    func score(forHoldOf seconds: Double) -> Double {
        guard seconds > 0 else { return 0 }
        let capTime = (multiplierCap - 1) / multiplierGainPerSecond
        if seconds <= capTime {
            return pointsPerSecond * (seconds + multiplierGainPerSecond / 2 * seconds * seconds)
        }
        let beforeCap = pointsPerSecond * (capTime + multiplierGainPerSecond / 2 * capTime * capTime)
        return beforeCap + pointsPerSecond * multiplierCap * (seconds - capTime)
    }

    func multiplier(forHoldOf seconds: Double) -> Double {
        min(1 + multiplierGainPerSecond * max(seconds, 0), multiplierCap)
    }

    private func lerp(_ a: Double, _ b: Double, _ t: Double) -> Double {
        a + (b - a) * t
    }
}
