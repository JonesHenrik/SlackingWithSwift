//
//  PaulGameApp.swift
//  PaulGame
//
//  Created by Nick Melekian on 8/12/26.
//

import SwiftUI

@main
struct PaulGameApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
