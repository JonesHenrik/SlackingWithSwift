//
//  PaulGameTests.swift
//  PaulGameTests
//
//  Created by Nick Melekian on 8/12/26.
//

import Testing
@testable import PaulGame

struct PaulGameTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
        // Swift Testing Documentation
        // https://developer.apple.com/documentation/testing
    }

}
